DB_SETTINGS = {
    'dbname': 'kursach',
    'user': 'postgres',
    'password': '1337',
    'host': 'localhost',
    'port': '5432'
}
YANDEX_DISK_SETTINGS = {
    'token': 'y0_AgAAAAAkDuy1AAsJsAAAAAD2M2mQBfd3_MLVR7KpY-lDy60VP0DivQg',
    'folder': 'backup'  # Папка для сохранения резервной копии на Яндекс.Диске
}
